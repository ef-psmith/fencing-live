Stage 1	- Ready for check in, poules not drawn

Stage 2 - Poules drawn, none entered

Stage 3 - Poules complete & ranked, tableau not drawn

Stage 4 - Tableau drawn (L64)

Stage 5 - Complete

A Grade Stage 4 - A Grade @ Stage 4 including a prelim tableau of 64

